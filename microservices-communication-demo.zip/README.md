# Microservices Communication Demo

Цей репозиторій демонструє різні підходи до комунікації мікросервісів:

## Приклади включають:
- Синхронна комунікація (REST API)
- Асинхронна комунікація (RabbitMQ, Kafka)
- gRPC
- Event Sourcing + CQRS
- Circuit Breaking + Backpressure
- API Gateway (FastAPI / NGINX)
- Service Mesh (інтеграція через Istio — для Kubernetes)

## Запуск

```bash
docker-compose up --build
```

## Структура проекту

```
rest/
kafka/
grpc/
circuit/
gateway/
```
